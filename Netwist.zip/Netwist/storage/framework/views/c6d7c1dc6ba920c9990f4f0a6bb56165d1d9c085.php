<div align="center">
<p>&nbsp;</p>
<h1>Add City Details</h1>
<p>&nbsp;</p>
<form method="post" action="/cities/<?php echo e($city->id); ?>">
<?php echo e(method_field('PATCH')); ?>

<?php echo e(csrf_field()); ?>


<?php if($errors->any()): ?>
<?php echo e($errors->first('city_name')); ?>

<?php endif; ?>

<tr><th><b>City Name:</b></th><td><input type="text" name="city_name" value="<?php echo e(old('city_name', $city->city_name)); ?>"></td>
</tr>
<br>
<br>
<?php if($errors->any()): ?>
<?php echo e($errors->first('state_id')); ?>

<?php endif; ?>
<tr>
<th><b>State Name:</b></th><td>
<select type="text" name="state_id" value="<?php echo e(old('state_id', $city->state_id)); ?>">
<option value="">Select State</option>
<?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($state_detail->id); ?>" <?php echo e(( $state_detail->id == $city->state_id) ? 'selected' : ''); ?>><?php echo e($state_detail->state_name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</td>
</tr>
<br>
<br>
<tr>
<input type="submit" name="sub" value="Update">
</tr>
</form>
</div>
